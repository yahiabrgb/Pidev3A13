/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pidv;

import Service.ServiceMessage;
import java.sql.SQLException;
import java.util.List;
import pidv.Entite.Message;

/**
 *
 * @author Med Ch
 */
public class tt {
    public static void main(String[] args) {
        ServiceMessage ser = new ServiceMessage();
        
        Message p2 = new Message(4, 77, "Booogooo");
        
        try {
//         
System.out.println(ser.Findmsg(p2));

        } catch (SQLException ex) {
            System.out.println(ex);
        }
       
    }
    
}
