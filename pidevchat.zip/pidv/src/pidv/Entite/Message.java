/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pidv.Entite;

/**
 *
 * @author Med Ch
 */
public class Message {
    private int chid;
    private int userid;
    private String message;
    
    public Message(int chid, int userid, String message){
        this.chid=chid;
        this.userid=userid;
        this.message=message;
    
}
    public int getchid()
    {
        return chid;
    }
    public int getuserid()
    {
        return userid;
    }
    public String getmsg()
    {
        return message;
    }
    
    public void setchid(int x)
     {
         chid=x;
     }
    public void setuserid(int x)
     {
         userid=x;
     }
    public void setmsg(String x)
     {
         message=x;
     }
    
    public String toString() {
        return "Message{" + "chid=" + chid + ", userid=" + userid + ", message=" + message + '}';
    }
    
}
