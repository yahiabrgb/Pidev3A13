package pidv;

import Service.ServiceChat;
import Service.ServiceMessage;
import Utils.DataBase;
import java.sql.*;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import pidv.Entite.Chat;
import pidv.Entite.Message;

/**
 *
 * @author House
 */
public class testt {
    
    public static void main(String[] args) {
        ServiceChat ser = new ServiceChat();
        
        Chat p1 = new Chat(2, 45, 3);
        
        try {
//         

           System.out.println( ser.Findchat(p1.getuser1id(),p1.getuser2id()));

        } catch (SQLException ex) {
            System.out.println(ex);
        }
      
    
     
    }
    
}